#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>

// 寫入回調函數，用於處理從 server 端接收到的數據
size_t write_callback(void *ptr, size_t size, size_t nmemb, FILE *data) {
    size_t written = fwrite(ptr, size, nmemb, data);
    return written;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <URL> <output_file>\n", argv[0]);
        return 1;
    }

    const char *url = argv[1];
    const char *output_file = argv[2];

    CURL *curl;
    FILE *fp;
    CURLcode res;

    // 初始化 libcurl
    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();

    if (curl) {
        // 開啟文件，用於寫入下載內容
        fp = fopen(output_file, "wb");
        if (fp == NULL) {
            perror("Error opening file");
            return 1;
        }

        // 設置 URL
        curl_easy_setopt(curl, CURLOPT_URL, url);

        // 設置寫入回調函數
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);

        // 執行下載
        res = curl_easy_perform(curl);

        // 檢查是否發生錯誤
        if (res != CURLE_OK) {
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
        }

        // 關閉文件
        fclose(fp);

        // 清理
        curl_easy_cleanup(curl);
    } else {
        fprintf(stderr, "Error initializing curl\n");
    }

    // 清理 libcurl
    curl_global_cleanup();

    return 0;
}
